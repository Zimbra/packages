Format: 3.0 (native)
Source: zimbra-proxy-components
Binary: zimbra-proxy-components
Architecture: all
Version: 1.0.16-1zimbra8.8b1.20.04
Maintainer: Zimbra Packaging Services <packaging-devel@zimbra.com>
Standards-Version: 3.9.5
Build-Depends: debhelper (>= 9)
Package-List:
 zimbra-proxy-components deb mail optional arch=all
Checksums-Sha1:
 883b5b2bdb7b46592766942c2310d4cc043afafc 1784 zimbra-proxy-components_1.0.16-1zimbra8.8b1.20.04.tar.xz
Checksums-Sha256:
 00e39a5513ca746ce4cdf2e3d7ec3cceadd374d5fbf250ec507bdeccfef357f4 1784 zimbra-proxy-components_1.0.16-1zimbra8.8b1.20.04.tar.xz
Files:
 8800f56d0d9980c309cb975628051a01 1784 zimbra-proxy-components_1.0.16-1zimbra8.8b1.20.04.tar.xz
