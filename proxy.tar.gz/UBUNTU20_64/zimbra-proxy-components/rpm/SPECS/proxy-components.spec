Summary:            Zimbra components for proxy package
Name:               zimbra-proxy-components
Version:            1.0.16
Release:            1zimbra8.8b1ZAPPEND
License:            GPL-2
Requires:           zimbra-proxy-base, zimbra-nginx >= 1.24.0-1zimbra8.8b8ZAPPEND
Packager:           Zimbra Packaging Services <packaging-devel@zimbra.com>
Group:              Development/Languages
AutoReqProv:        no

%define debug_package %{nil}

%changelog
* Fri Oct 16 2026 Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.16
- PREAPPS-9828: Add http_sub_module for the Modern UI CSP nonce
* Wed Jun 10 2026 Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.15
- Fix ZBUG-5593
* Tue Jun 03 2025  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.14
- Fix ZBUG-17297
* Wed Jan 29 2025  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.13
- Fix ZBUG-4637
* Mon Feb 05 2024  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.12
- Upgraded zimbra-nginx to 1.24.0
* Tue Jun 13 2023  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.11
- Updated zimbra-nginx
* Fri May 06 2022  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.10
- Updated zimbra-nginx,Fix ZBUG-2738
* Sun Jul 25 2021  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.9
- Updated zimbra-nginx to 1.20.0
* Thu Jan 21 2021  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.8
- Updated zimbra-nginx
* Thu Jan 21 2021  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.7
- Updated zimbra-nginx
* Sat Dec 05 2020  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.6
- Updated zimbra-nginx package to 1.19.0
* Mon Oct 19 2020  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.5
- Updated zimbra-nginx package
* Tue Mar 17 2020  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.4
- Updated zimbra-nginx package
* Tue Feb 12 2019  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.3
- Updated zimbra-nginx package
* Tue Sep 5 2018  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.2
- Updated zimbra-nginx package
* Tue Jul 18 2017  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.1
- Updated zimbra-nginx package
* Wed Sep 09 2015  Zimbra Packaging Services <packaging-devel@zimbra.com> - 1.0.0
- Initial Release

%description
Zimbra proxy components pulls in all the packages used by
zimbra-proxy

%files
