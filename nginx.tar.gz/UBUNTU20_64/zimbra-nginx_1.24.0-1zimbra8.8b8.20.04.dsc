Format: 3.0 (quilt)
Source: zimbra-nginx
Binary: zimbra-nginx, zimbra-nginx-dbg
Architecture: any
Version: 1.24.0-1zimbra8.8b8.20.04
Maintainer: Zimbra Packaging Services <packaging-devel@zimbra.com>
Uploaders: Zimbra Packaging Services <packaging-devel@zimbra.com>
Homepage: http://nginx.org
Standards-Version: 3.9.5
Build-Depends: debhelper (>= 9), m4, dpkg-dev (>= 1.15.7), libpcre3-dev, libz-dev, zimbra-openssl-dev (>= 3.0.9-1zimbra8.8b1ZAPPEND), zimbra-cyrus-sasl-dev (>= 2.1.28-1zimbra8.7b4ZAPPEND)
Package-List:
 zimbra-nginx deb utils optional arch=any
 zimbra-nginx-dbg deb debug extra arch=any
Checksums-Sha1:
 340756ed9ada1f25a085c65069185649bb4938f2 1161149 zimbra-nginx_1.24.0.orig.tar.gz
 35fcf23f2dcc490a2ec1aa524fca80055a1ecd0d 211940 zimbra-nginx_1.24.0-1zimbra8.8b8.20.04.debian.tar.xz
Checksums-Sha256:
 117497753a7c0a90c4ff0ab04d1bc99c69fe46baf99c8219750796677b6e8a2b 1161149 zimbra-nginx_1.24.0.orig.tar.gz
 3e2e35787194df9eeeb89a07e7d461a46abe40635b2852a2f8d3be672b580a26 211940 zimbra-nginx_1.24.0-1zimbra8.8b8.20.04.debian.tar.xz
Files:
 cdb9e6efd57e9b65e284c8087948a8a7 1161149 zimbra-nginx_1.24.0.orig.tar.gz
 ff15e9c99033be7ef7ff983b72b0f399 211940 zimbra-nginx_1.24.0-1zimbra8.8b8.20.04.debian.tar.xz
